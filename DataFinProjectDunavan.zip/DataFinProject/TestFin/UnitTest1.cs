//Rob Dunavan
//5/21/2022
//UnitTest1
using DataFinProject;
using Xunit;
namespace TestFin
{
    public class UnitTest1
    {
        //Test userName from the UserSignIn class
        [Fact]
        public void TestUserName()
        {
            var user = new UserSignIn();
            string userName = "Katrina Walter MD";//string userName
            user.SetUserName(userName);
            var name = user.GetUserName();// var name
            Assert.Equal("Katrina Walter MD", name);
        }
        //Test userAddress from the UserSignIn class
        [Fact]
        public void TestUserAddress()
        {
            var user = new UserSignIn();
            string userAddress = "9781 Merl Well Apt. 781";//string userAddress
            user.SetUserAddress(userAddress);
            var address = user.GetUserAddress();// var address
            Assert.Equal("9781 Merl Well Apt. 781", address);
        }
        //Test userCity from the UserSignIn class

        [Fact]
        public void TestUserCity()
        {
            var user = new UserSignIn();
            string userCity = "Kaylinborough";// string userCity
            user.SetUserCity(userCity);
            var city = user.GetUserCity();//var city
            Assert.Equal("Kaylinborough", city);
        }
        //Test patientName from the patientSignIn class
        [Fact]
        public void TestPatientName()
        {
            var patient = new patientSignIn();
            string patientName = "Brigitte Pfeffer";//string patientName
            patient.SetPatientName(patientName);
            var name = patient.GetPatientName();// var name
            Assert.Equal("Brigitte Pfeffer", name);
        }
        //Test patientRoomNumber from the patientSignIn class

        [Fact]
        public void TestPatientRoomNumber()
        {
            var patient = new patientSignIn();
            int patientRoomNumber = 19;// int patientRoomNumber
            patient.SetPatientRoomNumber(patientRoomNumber);
            var roomNumber = patient.GetPatientRoomNumber();// var roomNumber
            Assert.Equal(19, roomNumber);
        }

    }
}