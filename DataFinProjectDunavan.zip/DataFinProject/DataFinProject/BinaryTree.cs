﻿//Rob Dunavan
//5/19/22
//This class creates a binary tree
namespace DataFinProject
{
    // Data Structure Binary Tree
    class BinaryTree
    {
        public Node root;

        public BinaryTree()
        {
            root = null;
        }
        //Sorting method
        //printInOrder Function

        public void printInOrder(Node node)
        {
            if (node == null)
                return;

            /* first recur on left child */
            printInOrder(node.left);

            /* then print the data of node */
            Console.Write(node.lName + " ");

            /* now recur on right child */
            printInOrder(node.right);
        }
        //insert Function
        public void insert(Node root, string lastName)
        {
            
            if (root == null)
            {
                root = new Node(lastName);
                //Console.WriteLine("insert top");// output to test correction path of Node
            }
            else
            {
                if (root.lName.Length >= lastName.Length)
                {
                    if (root.left == null)
                    {
                        root.left = new Node(lastName);
                      //  Console.WriteLine("insert left");// output to test correction path of Node
                    }
                    else
                    {
                        insert(root.left, lastName);
                    }
                }
                else if (root.right == null)
                {
                    root.right = new Node(lastName);
                   // Console.WriteLine("insert right");// output to test correction path of Node
                }
                else
                {
                    insert(root.right, lastName);
                }

            }
        }
    }
}
       
