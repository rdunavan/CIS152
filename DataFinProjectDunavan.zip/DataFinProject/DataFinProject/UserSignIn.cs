﻿//Rob Dunavan
//5/19/22
//This class is UserSignIn 
//class UserSign
public  class UserSignIn
    {
        //Variables
        private int id;
        private string userName;
        private string userAddress;
        private string userCity;
        //Constructor
        public UserSignIn()
        {
            userName = userName;
            userAddress = userAddress;  
            userCity = userCity;
        }
        //Get Company
        public String GetUserName()
        {
            return userName;
        }
        //Set Company
        public void SetUserName(string _userName)
        {
             userName = _userName;
        }
        //Setter
        public void SetUserAddress(string _userAddress)
        {
             userAddress = _userAddress;
        }
        //Getter
        public string GetUserAddress()
        {
            return userAddress;
        }
        //Setter
        public void SetUserCity(string _userCity)
        {
            userCity = _userCity;
        }
        //Getter
        public String GetUserCity()
        {
            return userCity;
        }
    }

