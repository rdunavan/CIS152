﻿//Rob Dunavan
//5/21/2022
//Class Node
namespace DataFinProject
{
    class Node
    {
        public string fName;
        public int roomNumber;
        public string lName;
        public Node left;
        public Node right;
        //Constructor
        public Node(string lastName)
        {
            lName = lastName;
            left = null;
            right = null;

        }
    }
}
