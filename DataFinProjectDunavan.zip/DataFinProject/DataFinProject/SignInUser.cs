﻿//Rob Dunavan
//5/19/22
//This class asking for user input and turns its to a Queue

namespace DataFinProject
{
    class SignInUser
    {
        public string userName;
        public string User()
        {
            LinkedList<String> my_list = new LinkedList<String>();
            Console.WriteLine("-------------------------------------\n");
            UserSignIn mysign = new UserSignIn();
            Console.WriteLine("Please enter your full name");// Outputs for the user
            userName = Console.ReadLine();// userName inputs from user
            mysign.SetUserName(userName);
            var userN = mysign.GetUserName();
            my_list.AddLast(userN);

            Console.WriteLine("-------------------------------------\n");
            Console.WriteLine("Please enter your address");// Outputs for the user
            string userAddress = Console.ReadLine();// userAddress inputs from user
            mysign.SetUserAddress(userAddress);
            var userA = mysign.GetUserAddress();
            my_list.AddLast(userA);

            Console.WriteLine("-------------------------------------\n");
            Console.WriteLine("Please enter your city");// Outputs for the user
            string userCity = Console.ReadLine();// userAddress inputs from user
            mysign.SetUserCity(userCity);
            var userC = mysign.GetUserCity();
            my_list.AddLast(userC);

            
            Console.WriteLine("-------------------------------------\n");
            Console.WriteLine("Press enter to finish");
            Console.WriteLine(DateTime.Now);// calls the date time method
            Console.ReadLine();
           
            Console.WriteLine("-------------------------------------\n");
           
            Console.WriteLine("Here is your information:");

            // Accessing the elements of
            // LinkedList Using foreach loop
            foreach (string str in my_list)
            {
                Console.WriteLine(str);
            }
            return userN;
        }


    }
}
