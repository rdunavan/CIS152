﻿//Rob Dunavan
//5/24/2024
using DataFinProject;
using System;
class Driver
{
    public Node root;
    static void Main(string[] args)
    {
        UserInterface myUserFace = new UserInterface();
        myUserFace.UI();
    }
}











