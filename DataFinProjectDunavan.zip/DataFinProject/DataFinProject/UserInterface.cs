﻿//Rob Dunavan
//5/24/2024
//This userInterface class is a user Interface for this project.
namespace DataFinProject
{
    class UserInterface
    {
        public UserInterface()
        {
        }
        Node root;
        string lastName;
        patientSignIn myPatient = new patientSignIn();
        BinaryTree myTree = new BinaryTree();
        //These are the names you would need to test the code
        //Elvis Presley
        //Chuck Berry
        //Marilyn Monroe
        //Andrey Hepburn

        //Method UI
        public void UI()
        {
            patientSignIn myPatSignIn = new patientSignIn();//myPatSignIn
            string userName = "Elvis Presley";
            myPatSignIn.SetPatientName(userName);
            var usName = myPatSignIn.GetPatientName();
            //Console.WriteLine(usName);//Patient
            myTree.root = new Node(userName);// creates root for binary search tree

            string userName1 = "Chuck Berry";
            myPatSignIn.SetPatientName(userName1);
            string usName1 = myPatSignIn.GetPatientName();
            //Console.WriteLine(usName1);//Patient
            myTree.insert(myTree.root, usName1);// add node to root for binary search tree

            string userName2 = "Marilyn Monroe";
            myPatSignIn.SetPatientName(userName2);
            string usName2 = myPatSignIn.GetPatientName();
            //Console.WriteLine(usName2);//Patient
            myTree.insert(myTree.root, usName2);// add node to root for binary search tree

            string userName3 = "Andrey Hepburn";
            myPatSignIn.SetPatientName(userName3);
            string usName3 = myPatSignIn.GetPatientName();
            //Console.WriteLine(usName3);//Patient
            myTree.insert(myTree.root, usName3);// add node to root for binary search tree

            Console.WriteLine("Welcome to the Hospital");
            SignInUser signInUser = new SignInUser();
            signInUser.User();
            Console.WriteLine("Please enter the patient's name:");

            string user = Console.ReadLine();
            BinaryTree binaryTree = new BinaryTree();

            if (user == "Marilyn Monroe")
            {
                    Console.WriteLine("ROOM: 14\n" +
                    "D.O.B.: Feb 16, 1960\n" +
                    "DR:Dr. Cookie\nNURSE:Amber Schroeder\n" +
                    "Diagnosis: bowel obstruction ");
            }
            else if (user == "Elvis Presley")
            {
                    Console.WriteLine("ROOM: 18\n" +
                    "D.O.B.: Jan 08, 1935\n" +
                    "DR:Dr. Abbott\nNURSE:Valerie Gordon\n" +
                    "Diagnosis: pneumonia ");
            }
            else if (user == "Chuck Berry")
            {
                    Console.WriteLine("ROOM: 38\n" +
                    "D.O.B.: Oct 18, 1926\n" +
                    "DR:Dr. Cline\nNURSE:Bruce Crowley\n" +
                    "Diagnosis: hip replacement ");
            }
            else if (user == "Audrey Hepburn")
            {
                   Console.WriteLine("ROOM: 17\n" +
                   "D.O.B.: May 04, 1929\n" +
                   "DR:Dr. Stokes\nNURSE:Tammy Buchanan\n" +
                   "Diagnosis: heart failure");
            }
            else
            {
                Console.WriteLine("Please try again");
            }
            myTree.printInOrder(myTree.root);//sorting method from the binary tree
        }
    }
}
