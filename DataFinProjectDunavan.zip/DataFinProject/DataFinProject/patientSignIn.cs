﻿//Rob Dunavan
//5/19/22

namespace DataFinProject
{
    public class patientSignIn
    {
        //variables
        private int id;
        public string patientName;
        public int patientRoomNumber;

        //constructor
        public patientSignIn()
        {
            id = id;
            patientName = patientName;
            patientRoomNumber = patientRoomNumber;
        }

        //Getter Functions 
        public String GetPatientName()
        {
            return patientName;
        }
        //Setter Functions
        public void SetPatientName(string _patientName)
        {
            patientName = _patientName;
        }
        //Getter Function
        public int GetPatientRoomNumber()
        {
            return patientRoomNumber;
        }
        //Setter Function
        public void SetPatientRoomNumber(int _patientRoomNumber)
        {
            patientRoomNumber = _patientRoomNumber;
        }
    }
}
