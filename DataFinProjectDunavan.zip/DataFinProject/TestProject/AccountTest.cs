using Microsoft.VisualStudio.TestTools.UnitTesting;


[TestClass]
public class AccountTest
{

    [TestMethod]
    public void TestUserName()
    {
        // Arrange
        UserSignIn bm = new UserSignIn();
        string userName = "Rob Dunavan";
        string fname = "Jerrod";
         bm.SetUserName(fname);
        bm.GetUserName();
        //Assert.AreEqual(name, " Dunavan");
        Assert.AreSame(userName, bm.GetUserName());
        //Assert.IsTrue(name.Contains("Rob Dunavan"));
    }
}


